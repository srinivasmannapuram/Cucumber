package testrunners;
import org.junit.runner.RunWith;
import org.junit.runner.Runner;

import cucumber.api.CucumberOptions; 
import cucumber.api.junit.Cucumber;

@RunWith((Class<? extends Runner>) io.cucumber.junit.CucumberOptions.class) 
@io.cucumber.testng.CucumberOptions(features="features",glue={"stepD"}) 


public class testrunner {

}


