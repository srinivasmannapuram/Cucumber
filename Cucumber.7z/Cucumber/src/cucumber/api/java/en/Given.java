package cucumber.api.java.en;

public @interface Given {

}
